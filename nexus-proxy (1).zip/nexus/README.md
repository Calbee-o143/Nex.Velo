# Nexus

Scramjet + Wisp proxy with tabs, a Wisp server picker, and a service-worker AdBlock.

    npm install
    npm start          # http://localhost:8080

Service workers need HTTPS (localhost is exempt). Settings are in the gear icon.
To pin a Scramjet version: npm i @mercuryworkshop/scramjet@<version>
